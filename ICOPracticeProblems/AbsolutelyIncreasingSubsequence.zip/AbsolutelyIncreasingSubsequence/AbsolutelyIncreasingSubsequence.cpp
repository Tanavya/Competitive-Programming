#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <stdio.h>
#include <queue>
#include <set>
#include <list>
#include <cmath>
#include <assert.h>
#include <bitset>
#include <cstring>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <iomanip> //cout << setprecision(node) << fixed << num
#include <stack>
using namespace std;
#define ll long long int

void solve()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    
    ll t;
    cin>>t;
    while(t--)
        {
        ll n, k;
        cin>>n>>k;
        vector<ll> v(n);
        for(ll i = 0;i<n;i++)
            cin>>v[i];
        vector< pair<ll, ll> > dp(n);
        for(ll i = 0;i<n;i++)
        {
            dp[i] = {1, -1};
            for(ll j = 0;j<i;j++)
            {
                if(dp[j].second==-1)
                {
                    if(dp[i].first<2)
                        dp[i].first = 2, dp[i].second = j;
                }
                else if(abs(v[dp[j].second]-v[j])<abs(v[j]-v[i]))
                {
                    if(dp[j].first+1==dp[i].first)
                    {
                        if(abs(v[j]-v[i])<abs(v[dp[i].second]-v[i]))
                            dp[i].first = dp[j].first+1, dp[i].second = j;
                    }
                    else if(dp[j].first+1>dp[i].first)
                        dp[i].first = dp[j].first+1, dp[i].second = j;
                }
            }
        }
        ll amax = 0, cur = 0;
        for(ll i = 0;i<n;i++)
            if(dp[i].first>amax)
                amax = dp[i].first, cur = i;
        vector<ll> ans;
        for(ll i = cur; i>=0;i = dp[i].second)
            ans.push_back(v[i]);
        cout<<ans.size()<<endl;
        if(k) {
            for(ll i = ans.size()-1;i>=0;i--) {
                cout<<ans[i]<<" ";
            }
            cout << endl;
        }
    }
}

void gentc(int t) {

    int T = 5;
    const ll maxai = 1e18;
    cout << T << endl;
    while (T--) {
        int N, K;
        if (t == 0) {
            N = (rand() % 5) + 1;
            if (N == 1) N++;
            K = 1;
        }
        else if (t < 5) {
            N = (rand() % 15) + 6;
            K = 0;
        }
        else if (t < 10) {
            N = (rand() % 15) + 6;
            K = 1;
        }
        else if (t < 15) {
            N = (rand() % 3501) + 500;
            K = 0;
        }
        else if (t < 20) {
            N = (rand() % 3501) + 500;
            K = 1;
        }
        printf("%d %d\n", N, K);

        if (t == 0) {
            for (int i = 0; i < N; i++) {
                int curr = (rand() % 20);
                if (rand() % 2) curr *= -1;
                printf("%d ", (rand() % (2*40)) - 20);
            }
            printf("\n");
        }
        else if (T == 1) {
            ll curr = -(rand() % maxai);
            for (int i = 1; i <= N; i++) {
                printf("%lld ", curr);
                curr += (1LL * i * i * 10000000);
            }
            printf("\n");
        }
        else {
            for (int i = 0; i < N; i++) {
                ll curr = (rand() % maxai);
                if (rand() % 2) curr *= -1;
                printf("%lld ", (rand() % (maxai) * 2) - (rand() % maxai));
            }
            printf("\n");
        }
    }
}

int main() {

    
    srand(time(NULL));
    
    for (int i = 0; i < 20; i++) {
        string loc = "input/input" + to_string(i) + ".txt";
        freopen(loc.c_str(), "w", stdout);
        gentc(i);
    }
    for (int i = 0; i < 20; i++) {
        string loc = "input/input" + to_string(i) + ".txt";
        freopen(loc.c_str(), "r", stdin);
        loc = "output/output" + to_string(i) + ".txt";
        freopen(loc.c_str(), "w", stdout);
        solve();
    }

}